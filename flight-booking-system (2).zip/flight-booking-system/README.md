# Flight Booking System (Java + MySQL)

A console-based flight booking application built with plain JDBC (no framework
magic) so you can see exactly how the database layer works.

## Features
- Search flights by origin/destination
- Book a flight (auto-creates passenger record if new, picks a specific seat)
- View bookings by email
- Cancel a booking (frees the seat back up)
- Admin: add new flights, list all flights
- Seat-count updates and booking creation are wrapped in **transactions**, so a
  booking can never be created without the seat count being decremented (and
  vice versa)

## Project structure
```
flight-booking-system/
├── pom.xml                     # Maven build file (pulls in mysql-connector-j)
├── schema.sql                  # Database schema + sample flights
└── src/main/java/com/flightbooking/
    ├── Main.java                # Console menu / entry point
    ├── db/DBConnection.java     # JDBC connection setup
    ├── model/                   # Flight, Passenger, Booking POJOs
    └── dao/                     # FlightDAO, PassengerDAO, BookingDAO
```

## Prerequisites
- JDK 17+
- Maven 3.8+
- MySQL 8.x server running locally (or reachable)

## 1. Set up the database
```bash
mysql -u root -p < schema.sql
```
This creates the `flight_booking_db` database, three tables
(`flights`, `passengers`, `bookings`), and a handful of sample flights.

## 2. Configure the connection
`DBConnection.java` reads from environment variables, falling back to
defaults (`root` / `password` / `localhost:3306`):

```bash
export FBS_DB_URL="jdbc:mysql://localhost:3306/flight_booking_db?useSSL=false&serverTimezone=UTC"
export FBS_DB_USER="root"
export FBS_DB_PASSWORD="your_password"
```

(Or just edit the defaults directly in `DBConnection.java`.)

## 3. Build and run
```bash
mvn clean package
java -jar target/flight-booking-system-jar-with-dependencies.jar
```

## Example session
```
1. Search flights
2. Book a flight
3. View my bookings
4. Cancel a booking
5. [Admin] Add a new flight
6. [Admin] List all flights
0. Exit
```

Search Hyderabad -> Delhi, note the flight ID, then book it — you'll be
prompted for your name/email/phone and a seat number, and given a booking ID
to use later for cancellation.

## Notes / things you may want to extend
- No authentication — anyone can hit the "admin" menu options. Add a login
  step if this needs to be multi-user/secure.
- Seat numbers aren't validated against total seat count/layout — any string
  is accepted as long as it's not already taken on that flight.
- For a real app you'd likely add: payment handling, flight editing/deletion,
  pagination for search results, and a proper logging framework instead of
  `System.out`.
