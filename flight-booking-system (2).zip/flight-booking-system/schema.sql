-- ============================================================
-- Flight Booking System - Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS flight_booking_db;
USE flight_booking_db;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS passengers;

-- ------------------------------------------------------------
-- Flights
-- ------------------------------------------------------------
CREATE TABLE flights (
    flight_id       INT AUTO_INCREMENT PRIMARY KEY,
    flight_number   VARCHAR(10)     NOT NULL UNIQUE,
    origin          VARCHAR(50)     NOT NULL,
    destination     VARCHAR(50)     NOT NULL,
    departure_time  DATETIME        NOT NULL,
    arrival_time    DATETIME        NOT NULL,
    price           DECIMAL(10, 2)  NOT NULL,
    total_seats     INT             NOT NULL DEFAULT 100,
    seats_available INT             NOT NULL DEFAULT 100,
    CHECK (seats_available >= 0 AND seats_available <= total_seats)
);

-- ------------------------------------------------------------
-- Passengers
-- ------------------------------------------------------------
CREATE TABLE passengers (
    passenger_id    INT AUTO_INCREMENT PRIMARY KEY,
    full_name       VARCHAR(100)    NOT NULL,
    email           VARCHAR(100)    NOT NULL UNIQUE,
    phone           VARCHAR(20)
);

-- ------------------------------------------------------------
-- Bookings
-- ------------------------------------------------------------
CREATE TABLE bookings (
    booking_id      INT AUTO_INCREMENT PRIMARY KEY,
    flight_id       INT             NOT NULL,
    passenger_id    INT             NOT NULL,
    seat_number     VARCHAR(5)      NOT NULL,
    booking_date    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status          ENUM('CONFIRMED', 'CANCELLED') NOT NULL DEFAULT 'CONFIRMED',
    FOREIGN KEY (flight_id) REFERENCES flights(flight_id),
    FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id),
    UNIQUE KEY unique_seat_per_flight (flight_id, seat_number, status)
);

-- ------------------------------------------------------------
-- Sample data
-- ------------------------------------------------------------
INSERT INTO flights (flight_number, origin, destination, departure_time, arrival_time, price, total_seats, seats_available) VALUES
('AI101', 'Hyderabad', 'Delhi',     '2026-08-01 06:00:00', '2026-08-01 08:15:00', 4500.00, 150, 150),
('AI202', 'Hyderabad', 'Mumbai',    '2026-08-01 09:30:00', '2026-08-01 11:00:00', 3800.00, 150, 150),
('6E305', 'Delhi',     'Bengaluru', '2026-08-02 14:00:00', '2026-08-02 16:45:00', 5200.00, 180, 180),
('SG410', 'Mumbai',    'Chennai',   '2026-08-03 18:20:00', '2026-08-03 20:10:00', 4100.00, 120, 120),
('UK550', 'Bengaluru', 'Hyderabad', '2026-08-04 07:45:00', '2026-08-04 09:00:00', 3200.00, 100, 100);
