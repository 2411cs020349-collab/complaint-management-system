package com.flightbooking;

import com.flightbooking.dao.BookingDAO;
import com.flightbooking.dao.FlightDAO;
import com.flightbooking.dao.PassengerDAO;
import com.flightbooking.model.Booking;
import com.flightbooking.model.Flight;
import com.flightbooking.model.Passenger;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final FlightDAO flightDAO = new FlightDAO();
    private static final PassengerDAO passengerDAO = new PassengerDAO();
    private static final BookingDAO bookingDAO = new BookingDAO();
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void main(String[] args) {
        System.out.println("=========================================");
        System.out.println("   Welcome to the Flight Booking System   ");
        System.out.println("=========================================");

        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            try {
                switch (choice) {
                    case "1" -> searchFlights();
                    case "2" -> bookFlight();
                    case "3" -> viewMyBookings();
                    case "4" -> cancelBooking();
                    case "5" -> addFlightAdmin();
                    case "6" -> listAllFlightsAdmin();
                    case "0" -> {
                        running = false;
                        System.out.println("Goodbye!");
                    }
                    default -> System.out.println("Invalid option, please try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Something went wrong: " + e.getMessage());
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n---------------- MENU ----------------");
        System.out.println("1. Search flights");
        System.out.println("2. Book a flight");
        System.out.println("3. View my bookings");
        System.out.println("4. Cancel a booking");
        System.out.println("5. [Admin] Add a new flight");
        System.out.println("6. [Admin] List all flights");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void searchFlights() throws SQLException {
        System.out.print("Origin city: ");
        String origin = scanner.nextLine().trim();
        System.out.print("Destination city: ");
        String destination = scanner.nextLine().trim();

        List<Flight> flights = flightDAO.searchFlights(origin, destination);
        if (flights.isEmpty()) {
            System.out.println("No flights found for that route.");
            return;
        }
        System.out.println("\nFlights found:");
        for (Flight f : flights) {
            System.out.println("  " + f);
        }
    }

    private static void bookFlight() throws SQLException {
        System.out.print("Enter flight ID to book: ");
        int flightId = readInt();

        Flight flight = flightDAO.getFlightById(flightId);
        if (flight == null) {
            System.out.println("No flight with that ID.");
            return;
        }
        if (flight.getSeatsAvailable() <= 0) {
            System.out.println("Sorry, that flight is fully booked.");
            return;
        }

        System.out.println("Selected: " + flight);

        System.out.print("Your full name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Your email: ");
        String email = scanner.nextLine().trim();
        System.out.print("Your phone: ");
        String phone = scanner.nextLine().trim();

        Passenger passenger = passengerDAO.findOrCreate(name, email, phone);

        String seatNumber;
        do {
            System.out.print("Choose a seat number (e.g. 12A): ");
            seatNumber = scanner.nextLine().trim().toUpperCase();
            if (bookingDAO.isSeatTaken(flightId, seatNumber)) {
                System.out.println("That seat is already taken. Try another.");
                seatNumber = null;
            }
        } while (seatNumber == null);

        int bookingId = bookingDAO.bookFlight(flightId, passenger.getPassengerId(), seatNumber);
        if (bookingId == -1) {
            System.out.println("Sorry, that flight just sold out.");
        } else {
            System.out.println("Booking confirmed! Your booking ID is " + bookingId +
                    " (seat " + seatNumber + "). Save this ID to manage your booking.");
        }
    }

    private static void viewMyBookings() throws SQLException {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine().trim();

        Passenger passenger = passengerDAO.findByEmail(email);
        if (passenger == null) {
            System.out.println("No passenger found with that email.");
            return;
        }

        List<Booking> bookings = bookingDAO.getBookingsForPassenger(passenger.getPassengerId());
        if (bookings.isEmpty()) {
            System.out.println("You have no bookings.");
            return;
        }

        System.out.println("\nYour bookings:");
        for (Booking b : bookings) {
            Flight f = flightDAO.getFlightById(b.getFlightId());
            String flightInfo = (f != null)
                    ? f.getFlightNumber() + " " + f.getOrigin() + " -> " + f.getDestination()
                    : "Flight #" + b.getFlightId();
            System.out.println("  " + b + " | " + flightInfo);
        }
    }

    private static void cancelBooking() throws SQLException {
        System.out.print("Enter booking ID to cancel: ");
        int bookingId = readInt();

        boolean cancelled = bookingDAO.cancelBooking(bookingId);
        if (cancelled) {
            System.out.println("Booking #" + bookingId + " has been cancelled and the seat released.");
        } else {
            System.out.println("Could not cancel: booking not found or already cancelled.");
        }
    }

    private static void addFlightAdmin() throws SQLException {
        System.out.println("-- Add new flight --");
        System.out.print("Flight number (e.g. AI777): ");
        String number = scanner.nextLine().trim();
        System.out.print("Origin: ");
        String origin = scanner.nextLine().trim();
        System.out.print("Destination: ");
        String destination = scanner.nextLine().trim();
        System.out.print("Departure (yyyy-MM-dd HH:mm): ");
        LocalDateTime departure = LocalDateTime.parse(scanner.nextLine().trim(), DATE_FMT);
        System.out.print("Arrival (yyyy-MM-dd HH:mm): ");
        LocalDateTime arrival = LocalDateTime.parse(scanner.nextLine().trim(), DATE_FMT);
        System.out.print("Price: ");
        BigDecimal price = new BigDecimal(scanner.nextLine().trim());
        System.out.print("Total seats: ");
        int seats = readInt();

        Flight flight = new Flight(0, number, origin, destination, departure, arrival, price, seats, seats);
        flightDAO.addFlight(flight);
        System.out.println("Flight " + number + " added.");
    }

    private static void listAllFlightsAdmin() throws SQLException {
        List<Flight> flights = flightDAO.getAllFlights();
        System.out.println("\nAll flights:");
        for (Flight f : flights) {
            System.out.println("  " + f);
        }
    }

    private static int readInt() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.print("Please enter a valid number: ");
            }
        }
    }
}
