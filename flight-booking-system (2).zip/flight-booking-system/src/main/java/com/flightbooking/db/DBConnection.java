package com.flightbooking.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Central place for creating JDBC connections to MySQL.
 * Update DB_URL / DB_USER / DB_PASSWORD for your environment,
 * or set them via environment variables (see getEnvOrDefault).
 */
public class DBConnection {

    private static final String DB_URL =
            getEnvOrDefault("FBS_DB_URL", "jdbc:mysql://localhost:3306/flight_booking_db?useSSL=false&serverTimezone=UTC");
    private static final String DB_USER =
            getEnvOrDefault("FBS_DB_USER", "root");
    private static final String DB_PASSWORD =
            getEnvOrDefault("FBS_DB_PASSWORD", "password");

    private static String getEnvOrDefault(String key, String defaultValue) {
        String value = System.getenv(key);
        return (value == null || value.isBlank()) ? defaultValue : value;
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found on classpath.", e);
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
