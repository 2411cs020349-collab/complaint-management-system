package com.flightbooking.dao;

import com.flightbooking.db.DBConnection;
import com.flightbooking.model.Passenger;

import java.sql.*;

public class PassengerDAO {

    public Passenger findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM passengers WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public Passenger findById(int passengerId) throws SQLException {
        String sql = "SELECT * FROM passengers WHERE passenger_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, passengerId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    /** Creates a new passenger and returns the generated ID. */
    public int createPassenger(Passenger passenger) throws SQLException {
        String sql = "INSERT INTO passengers (full_name, email, phone) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, passenger.getFullName());
            ps.setString(2, passenger.getEmail());
            ps.setString(3, passenger.getPhone());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        throw new SQLException("Failed to create passenger, no ID obtained.");
    }

    /** Finds an existing passenger by email, or creates one if none exists. */
    public Passenger findOrCreate(String fullName, String email, String phone) throws SQLException {
        Passenger existing = findByEmail(email);
        if (existing != null) return existing;

        Passenger p = new Passenger(0, fullName, email, phone);
        int id = createPassenger(p);
        p.setPassengerId(id);
        return p;
    }

    private Passenger mapRow(ResultSet rs) throws SQLException {
        return new Passenger(
            rs.getInt("passenger_id"),
            rs.getString("full_name"),
            rs.getString("email"),
            rs.getString("phone")
        );
    }
}
