package com.flightbooking.dao;

import com.flightbooking.db.DBConnection;
import com.flightbooking.model.Flight;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FlightDAO {

    /** Search flights by origin/destination (case-insensitive, partial match). */
    public List<Flight> searchFlights(String origin, String destination) throws SQLException {
        String sql = "SELECT * FROM flights WHERE LOWER(origin) LIKE ? AND LOWER(destination) LIKE ? " +
                     "AND seats_available > 0 ORDER BY departure_time";
        List<Flight> results = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + origin.toLowerCase() + "%");
            ps.setString(2, "%" + destination.toLowerCase() + "%");

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(mapRow(rs));
                }
            }
        }
        return results;
    }

    public List<Flight> getAllFlights() throws SQLException {
        String sql = "SELECT * FROM flights ORDER BY departure_time";
        List<Flight> results = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                results.add(mapRow(rs));
            }
        }
        return results;
    }

    public Flight getFlightById(int flightId) throws SQLException {
        String sql = "SELECT * FROM flights WHERE flight_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public void addFlight(Flight flight) throws SQLException {
        String sql = "INSERT INTO flights (flight_number, origin, destination, departure_time, " +
                     "arrival_time, price, total_seats, seats_available) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, flight.getFlightNumber());
            ps.setString(2, flight.getOrigin());
            ps.setString(3, flight.getDestination());
            ps.setTimestamp(4, Timestamp.valueOf(flight.getDepartureTime()));
            ps.setTimestamp(5, Timestamp.valueOf(flight.getArrivalTime()));
            ps.setBigDecimal(6, flight.getPrice());
            ps.setInt(7, flight.getTotalSeats());
            ps.setInt(8, flight.getTotalSeats());

            ps.executeUpdate();
        }
    }

    /** Decrements seats_available by 1. Uses a WHERE guard so it never goes negative. */
    public boolean decrementSeat(Connection conn, int flightId) throws SQLException {
        String sql = "UPDATE flights SET seats_available = seats_available - 1 " +
                     "WHERE flight_id = ? AND seats_available > 0";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            return ps.executeUpdate() == 1;
        }
    }

    /** Increments seats_available by 1 (used on cancellation). */
    public boolean incrementSeat(Connection conn, int flightId) throws SQLException {
        String sql = "UPDATE flights SET seats_available = seats_available + 1 " +
                     "WHERE flight_id = ? AND seats_available < total_seats";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, flightId);
            return ps.executeUpdate() == 1;
        }
    }

    private Flight mapRow(ResultSet rs) throws SQLException {
        return new Flight(
            rs.getInt("flight_id"),
            rs.getString("flight_number"),
            rs.getString("origin"),
            rs.getString("destination"),
            rs.getTimestamp("departure_time").toLocalDateTime(),
            rs.getTimestamp("arrival_time").toLocalDateTime(),
            rs.getBigDecimal("price"),
            rs.getInt("total_seats"),
            rs.getInt("seats_available")
        );
    }
}
