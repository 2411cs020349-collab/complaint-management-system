package com.flightbooking.dao;

import com.flightbooking.db.DBConnection;
import com.flightbooking.model.Booking;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {

    private final FlightDAO flightDAO = new FlightDAO();

    /**
     * Books a seat on a flight for a passenger, inside a single transaction so
     * the seat-count decrement and the booking row are always consistent.
     * Returns the new booking ID, or -1 if no seats were available.
     */
    public int bookFlight(int flightId, int passengerId, String seatNumber) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            boolean seatReserved = flightDAO.decrementSeat(conn, flightId);
            if (!seatReserved) {
                conn.rollback();
                return -1; // sold out
            }

            String sql = "INSERT INTO bookings (flight_id, passenger_id, seat_number, status) " +
                         "VALUES (?, ?, ?, 'CONFIRMED')";
            int bookingId;
            try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, flightId);
                ps.setInt(2, passengerId);
                ps.setString(3, seatNumber);
                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Booking insert failed, no ID obtained.");
                    bookingId = keys.getInt(1);
                }
            }

            conn.commit();
            return bookingId;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    /**
     * Cancels a booking and frees up the seat, in a single transaction.
     * Returns true if a confirmed booking was found and cancelled.
     */
    public boolean cancelBooking(int bookingId) throws SQLException {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            int flightId = -1;
            String selectSql = "SELECT flight_id FROM bookings WHERE booking_id = ? AND status = 'CONFIRMED'";
            try (PreparedStatement ps = conn.prepareStatement(selectSql)) {
                ps.setInt(1, bookingId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) flightId = rs.getInt("flight_id");
                }
            }

            if (flightId == -1) {
                conn.rollback();
                return false; // not found or already cancelled
            }

            String updateSql = "UPDATE bookings SET status = 'CANCELLED' WHERE booking_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setInt(1, bookingId);
                ps.executeUpdate();
            }

            flightDAO.incrementSeat(conn, flightId);

            conn.commit();
            return true;

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    public List<Booking> getBookingsForPassenger(int passengerId) throws SQLException {
        String sql = "SELECT * FROM bookings WHERE passenger_id = ? ORDER BY booking_date DESC";
        List<Booking> results = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, passengerId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    results.add(mapRow(rs));
                }
            }
        }
        return results;
    }

    public boolean isSeatTaken(int flightId, String seatNumber) throws SQLException {
        String sql = "SELECT 1 FROM bookings WHERE flight_id = ? AND seat_number = ? AND status = 'CONFIRMED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, flightId);
            ps.setString(2, seatNumber);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        return new Booking(
            rs.getInt("booking_id"),
            rs.getInt("flight_id"),
            rs.getInt("passenger_id"),
            rs.getString("seat_number"),
            rs.getTimestamp("booking_date").toLocalDateTime(),
            rs.getString("status")
        );
    }
}
