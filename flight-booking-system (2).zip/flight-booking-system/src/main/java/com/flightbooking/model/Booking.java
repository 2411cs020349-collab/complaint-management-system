package com.flightbooking.model;

import java.time.LocalDateTime;

public class Booking {
    private int bookingId;
    private int flightId;
    private int passengerId;
    private String seatNumber;
    private LocalDateTime bookingDate;
    private String status; // CONFIRMED or CANCELLED

    public Booking() {}

    public Booking(int bookingId, int flightId, int passengerId, String seatNumber,
                    LocalDateTime bookingDate, String status) {
        this.bookingId = bookingId;
        this.flightId = flightId;
        this.passengerId = passengerId;
        this.seatNumber = seatNumber;
        this.bookingDate = bookingDate;
        this.status = status;
    }

    public int getBookingId() { return bookingId; }
    public void setBookingId(int bookingId) { this.bookingId = bookingId; }

    public int getFlightId() { return flightId; }
    public void setFlightId(int flightId) { this.flightId = flightId; }

    public int getPassengerId() { return passengerId; }
    public void setPassengerId(int passengerId) { this.passengerId = passengerId; }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public LocalDateTime getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDateTime bookingDate) { this.bookingDate = bookingDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return String.format(
            "Booking #%d | Flight ID: %d | Seat: %s | Status: %s | Booked on: %s",
            bookingId, flightId, seatNumber, status, bookingDate
        );
    }
}
